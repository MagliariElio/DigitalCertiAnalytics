# Author: Anuar Elio Magliari
# Organization: Politecnico di Torino
